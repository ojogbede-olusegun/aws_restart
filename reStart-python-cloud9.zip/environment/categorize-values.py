myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]
for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))
    
myMixedTypeList = [4, 290511, 3.02, True, False, "My dog is on the chair.", "405"]
for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))
    